<h2 class="nav-tab-wrapper">
    <a href="<?php echo $slug; ?>&amp;tab=view" target="" class="nav-tab">View</a>
    <span class="nav-tab nav-tab-active">Modify</span>
    <a href="<?php echo $slug; ?>&amp;tab=add" target="" class="nav-tab">Add</a>
</h2>
