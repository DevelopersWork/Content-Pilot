import React from 'react';

const Presentation = () => {
	return (
		<React.Fragment>
			<h1>Dashboard</h1>
		</React.Fragment>
	);
};

export default Presentation;
