import ContainerComponent from './Container';

export default ContainerComponent;
