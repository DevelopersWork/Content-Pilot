<?php

/**
 * @package DWContentPilot
 */

namespace DW\ContentPilot\Tests\Credentials;

use PHPUnit\Framework\TestCase;

class sampleTest extends TestCase
{
    public function testAddition()
    {
        $result = 1 + 2;
        $this->assertEquals(3, $result);
    }
}
